//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DXFW8_UG.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/adiel/Downloads/pro-player-hub-main/pro-player-hub-main/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-35u9E07j.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-35u9E07j.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/adiel/Downloads/pro-player-hub-main/pro-player-hub-main/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DFrVzaJV.js"]
	}
} });
//#endregion
export { tsrStartManifest };
