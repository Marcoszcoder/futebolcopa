import { n as __toESM } from "../_runtime.mjs";
import { c as performance_default } from "../_libs/h3+rou3+srvx+unenv.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { C as Check, D as Award, E as Bell, O as Apple, S as ChevronDown, T as Brain, _ as Gift, a as Users, b as Crown, c as TrendingUp, d as Sparkles, f as Smartphone, g as Instagram, h as Play, i as WifiOff, l as Target, m as RefreshCw, n as Youtube, o as Twitter, p as Shield, r as X, s as Trophy, t as Zap, u as Star, v as Flame, w as Calendar, x as Clock, y as Dumbbell } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DE5UKwSv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var stadium_hero_default = "/assets/stadium-hero-DRTmcld3.jpg";
var stadium_cta_default = "/assets/stadium-cta-DJkkUmQf.jpg";
var player_1_default = "/assets/player-1-Bdu_p7UC.jpg";
var player_2_default = "/assets/player-2-B5M3eDj7.jpg";
var player_3_default = "/assets/player-3-D3L56Lwe.jpg";
var player_4_default = "/assets/player-4-Bqzv8zrN.jpg";
var testimonial_1_default = "/assets/testimonial-1-CUy38xtk.jpg";
var testimonial_2_default = "/assets/testimonial-2-CRlEPF6h.jpg";
var testimonial_3_default = "/assets/testimonial-3-D2vQl5Vj.jpg";
function useReveal() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const io = new IntersectionObserver(([e]) => {
			if (e.isIntersecting) {
				el.classList.add("animate-rise");
				io.disconnect();
			}
		}, { threshold: .15 });
		io.observe(el);
		return () => io.disconnect();
	}, []);
	return ref;
}
function Counter({ to, suffix = "", duration = 1600 }) {
	const [n, setN] = (0, import_react.useState)(0);
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		let started = false;
		const io = new IntersectionObserver(([e]) => {
			if (e.isIntersecting && !started) {
				started = true;
				const start = performance_default.now();
				const tick = (t) => {
					const p = Math.min(1, (t - start) / duration);
					setN(Math.round(to * (1 - Math.pow(1 - p, 3))));
					if (p < 1) requestAnimationFrame(tick);
				};
				requestAnimationFrame(tick);
			}
		}, { threshold: .4 });
		io.observe(el);
		return () => io.disconnect();
	}, [to, duration]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		ref,
		children: [n.toLocaleString("pt-BR"), suffix]
	});
}
function Bar({ label, value, delay = 0 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1.5 flex items-center justify-between text-xs uppercase tracking-widest",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-white/70",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-neon font-bold",
			children: value
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 w-full overflow-hidden rounded-full bg-white/10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full rounded-full bg-[color:var(--neon)] shadow-[0_0_12px_rgba(184,255,0,0.9)]",
			style: {
				width: `${value}%`,
				animation: `bar-grow 1.4s ${delay}ms ease-out both`
			}
		})
	})] });
}
var players = [
	{
		name: "R. Silva",
		spec: "Velocidade",
		img: player_2_default,
		stats: {
			Velocidade: 96,
			Drible: 82,
			Finalização: 78,
			Passe: 74,
			Controle: 80
		}
	},
	{
		name: "J. Neto",
		spec: "Drible",
		img: player_1_default,
		stats: {
			Velocidade: 84,
			Drible: 95,
			Finalização: 82,
			Passe: 88,
			Controle: 92
		}
	},
	{
		name: "M. Oliveira",
		spec: "Finalização",
		img: player_4_default,
		stats: {
			Velocidade: 80,
			Drible: 84,
			Finalização: 96,
			Passe: 78,
			Controle: 82
		}
	},
	{
		name: "T. Costa",
		spec: "Controle",
		img: player_3_default,
		stats: {
			Velocidade: 78,
			Drible: 90,
			Finalização: 82,
			Passe: 92,
			Controle: 95
		}
	}
];
var vslCraques = [
	{
		name: "Messi",
		img: player_1_default
	},
	{
		name: "Cristiano",
		img: player_2_default
	},
	{
		name: "Vini Jr",
		img: player_3_default
	},
	{
		name: "Mbappé",
		img: player_4_default
	}
];
function VslPhone() {
	const [active, setActive] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto w-[300px] sm:w-[340px] animate-float",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 -z-10 blur-3xl opacity-70",
			style: { background: "radial-gradient(circle at 50% 40%, rgba(184,255,0,0.55), transparent 60%)" }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative rounded-[3rem] bg-neutral-900 p-3 shadow-[0_40px_80px_rgba(0,0,0,0.6)] ring-1 ring-white/10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-1/2 top-3 z-20 h-6 w-28 -translate-x-1/2 rounded-full bg-black" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-[2.4rem] bg-gradient-to-b from-neutral-950 to-black p-5 pt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: player_1_default,
									alt: "Craque João",
									className: "h-11 w-11 rounded-full object-cover ring-2 ring-[color:var(--neon)]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-[color:var(--neon)] ring-2 ring-black animate-pulse-glow" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase tracking-widest text-white/40",
									children: "Seu treinador"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg leading-none",
									children: "Fale Craque João"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4 text-[color:var(--neon)]" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-xs text-white/70",
						children: "Bora, atleta? Preparei o módulo perfeito para você hoje 💪"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-5 rounded-2xl bg-gradient-to-br from-[color:var(--neon)]/20 to-transparent p-4 ring-1 ring-[color:var(--neon)]/30",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase tracking-widest text-[color:var(--neon)]",
									children: "Módulo 03"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-display text-lg leading-tight",
									children: "Explosão & Sprint"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex items-center gap-3 text-[10px] text-white/60",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }), " 22 min"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-3 w-3" }), " +180 XP"]
									})]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "btn-neon flex items-center gap-1.5 rounded-xl px-3.5 py-2.5 text-[11px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-3.5 w-3.5 fill-black" }), "Iniciar"]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest text-white/40",
								children: "Escolha seu craque"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-neon",
								children: "Ver todos"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-between gap-2",
							children: vslCraques.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActive(i),
								className: "flex flex-col items-center gap-1.5 focus:outline-none",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "relative flex h-14 w-14 items-center justify-center rounded-full p-[2px] transition " + (active === i ? "bg-[color:var(--neon)] shadow-[0_0_18px_var(--neon)]" : "bg-white/10"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: c.img,
										alt: c.name,
										className: "h-full w-full rounded-full object-cover ring-2 ring-black"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-semibold " + (active === i ? "text-neon" : "text-white/60"),
									children: c.name
								})]
							}, c.name))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-center text-[11px] text-white/60",
							children: [
								"Treine inspirado em ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white font-semibold",
									children: vslCraques[active].name
								}),
								" — plano ajustado ao seu nível pela IA."
							]
						})
					] })
				]
			})]
		})]
	});
}
var testimonials = [
	{
		name: "Rafael M.",
		city: "São Paulo, SP",
		img: testimonial_1_default,
		text: "Antes eu treinava sem foco. Agora evoluo todos os dias e vejo resultado real na quadra."
	},
	{
		name: "Diego S.",
		city: "Rio de Janeiro, RJ",
		img: testimonial_2_default,
		text: "Melhorei minha velocidade em apenas 30 dias. O app é viciante — quero bater todos os desafios."
	},
	{
		name: "Bruno L.",
		city: "Belo Horizonte, MG",
		img: testimonial_3_default,
		text: "Nunca pensei que um aplicativo fosse tão completo. IA, ranking, cartas… parece um jogo, mas é sério."
	}
];
var faq = [
	{
		q: "Funciona para iniciantes?",
		a: "Sim. O plano se adapta ao seu nível — de quem nunca treinou a atletas experientes."
	},
	{
		q: "Posso treinar em casa?",
		a: "Pode. A maioria dos treinos usa pouco espaço e nenhum equipamento. Também temos rotinas para campo e quadra."
	},
	{
		q: "Preciso de academia?",
		a: "Não. A academia é opcional. Você evolui com treinos de campo, força funcional e mobilidade."
	},
	{
		q: "Serve para crianças e adolescentes?",
		a: "Sim, a partir de 10 anos, com intensidade ajustada automaticamente pela IA."
	},
	{
		q: "Recebo novos treinos?",
		a: "Toda semana. Além disso, a IA reprograma seu plano com base na sua evolução."
	}
];
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen overflow-x-hidden bg-[#0b0b0b] text-white selection:bg-[color:var(--neon)] selection:text-black",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrustBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VSL, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowItWorks, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayersCarousel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShowcase, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvolutionSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Challenges, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCards, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiCoach, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsProgress, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ranking, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comparison, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Benefits, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pricing, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQ, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCTA, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function Logo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative flex h-9 w-9 items-center justify-center rounded-xl bg-[color:var(--neon)] text-black glow-neon-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, {
				className: "h-5 w-5",
				strokeWidth: 2.5
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-display text-xl tracking-wider",
			children: ["TREINO ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-neon",
				children: "DA COPA"
			})]
		})]
	});
}
function Nav() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "fixed top-0 left-0 right-0 z-50",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-4 flex max-w-7xl items-center justify-between rounded-2xl glass-strong px-4 py-3 md:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-7 text-sm text-white/70 md:flex",
					children: [
						"Recursos",
						"Jogadores",
						"App",
						"Planos",
						"FAQ"
					].map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `#${l.toLowerCase()}`,
						className: "hover:text-neon transition-colors",
						children: l
					}, l))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#planos",
					className: "btn-neon rounded-xl px-4 py-2 text-xs md:text-sm",
					children: "Baixar App"
				})
			]
		})
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative flex min-h-screen flex-col items-center justify-center overflow-hidden pt-28 pb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: stadium_hero_default,
				alt: "Estádio iluminado",
				width: 1920,
				height: 1280,
				className: "absolute inset-0 -z-10 h-full w-full object-cover opacity-60"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 -z-10",
				style: { background: "radial-gradient(ellipse at 50% 30%, rgba(184,255,0,0.18), transparent 60%), linear-gradient(180deg, rgba(11,11,11,0.4) 0%, rgba(11,11,11,0.85) 60%, #0b0b0b 100%)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-3xl px-6 text-center animate-rise",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-6 inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs uppercase tracking-widest text-white/80",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-[color:var(--neon)] animate-pulse-glow" }), "Temporada 2026 · Novos treinos toda semana"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-display text-5xl leading-[0.95] sm:text-6xl md:text-7xl lg:text-[5.5rem]",
						children: [
							"TREINE COMO",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"OS ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-neon",
								children: "JOGADORES"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"DA COPA"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "my-8 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VslPhone, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mx-auto max-w-xl text-base text-white/70 md:text-lg",
						children: [
							"Descubra os treinos inspirados nos maiores craques do mundo e evolua sua",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-white",
								children: " velocidade, drible, explosão, finalização e resistência"
							}),
							" — com IA que se adapta a você todos os dias."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#planos",
							className: "btn-neon inline-flex items-center gap-2 rounded-2xl px-7 py-4 text-sm md:text-base",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-5 w-5" }), " Começar Agora"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#recursos",
							className: "inline-flex items-center gap-2 rounded-2xl glass px-6 py-4 text-sm font-semibold text-white transition hover:bg-white/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4" }), " Ver Demonstração"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex flex-wrap items-center justify-center gap-6 text-sm text-white/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex -space-x-2",
								children: [
									testimonial_1_default,
									testimonial_2_default,
									testimonial_3_default
								].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: s,
									alt: "",
									width: 28,
									height: 28,
									className: "h-7 w-7 rounded-full ring-2 ring-black object-cover"
								}, i))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
								className: "text-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, { to: 12e4 }), "+"]
							}), " atletas treinando"] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [[...Array(5)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4 fill-[color:var(--neon)] text-[color:var(--neon)]" }, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-white",
									children: "4.9/5"
								})
							})]
						})]
					})
				]
			})
		]
	});
}
function TrustBar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-y border-white/5 bg-black/60 py-6 backdrop-blur",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex max-w-7xl flex-wrap items-center justify-around gap-4 px-6 text-white/60",
			children: [
				{
					icon: Users,
					label: "120.000+ atletas"
				},
				{
					icon: Star,
					label: "Nota 4.9/5"
				},
				{
					icon: Smartphone,
					label: "Android"
				},
				{
					icon: Apple,
					label: "iPhone"
				},
				{
					icon: RefreshCw,
					label: "Atualizado diariamente"
				},
				{
					icon: Shield,
					label: "Pagamento seguro"
				}
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(i.icon, { className: "h-4 w-4 text-[color:var(--neon)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: i.label
				})]
			}, i.label))
		})
	});
}
function VSL() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "recursos",
		ref: useReveal(),
		className: "opacity-0 py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "group relative overflow-hidden rounded-3xl ring-1 ring-white/10 shadow-[0_40px_100px_rgba(0,0,0,0.6)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/cr7.jpeg",
					alt: "Como funciona o método",
					className: "w-full h-auto object-cover transition duration-700 group-hover:scale-105"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.3em] text-neon",
					children: "O método"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl md:text-5xl",
					children: "Veja como milhares evoluem treinando como profissionais"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-white/70",
					children: "Um método completo, gamificado e personalizado — do jogador de fim de semana ao atleta que quer chegar ao próximo nível."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 space-y-3",
					children: [
						"Evolua mais rápido com plano semanal",
						"Treinos guiados passo a passo em vídeo",
						"Desafios diários com XP e recompensas",
						"IA personalizada que evolui com você",
						"Resultados reais em 30 dias"
					].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 rounded-xl glass px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-5 w-5 shrink-0 text-[color:var(--neon)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm md:text-base",
							children: t
						})]
					}, t))
				})
			] })]
		})
	});
}
function HowItWorks() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Método",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Como ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "funciona"
				})] }),
				sub: "Quatro passos simples para começar hoje mesmo."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					{
						icon: Users,
						t: "Escolha seu craque",
						d: "Selecione o jogador que combina com o seu estilo."
					},
					{
						icon: Brain,
						t: "Receba um plano com IA",
						d: "Um plano personalizado é montado em segundos."
					},
					{
						icon: Dumbbell,
						t: "Treine todos os dias",
						d: "Rotinas guiadas com vídeo, tempo e XP."
					},
					{
						icon: TrendingUp,
						t: "Veja sua evolução",
						d: "Gráficos, cartas e ranking mostram seu progresso."
					}
				].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group relative rounded-3xl glass p-6 transition hover:-translate-y-1 hover:bg-white/[0.06]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[color:var(--neon)] text-black glow-neon-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { className: "h-7 w-7" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute right-5 top-5 font-display text-4xl text-white/10 group-hover:text-neon transition",
							children: ["0", i + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl",
							children: s.t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-white/60",
							children: s.d
						})
					]
				}, s.t))
			})]
		})
	});
}
function SectionHead({ over, title, sub }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.3em] text-neon",
				children: over
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 font-display text-4xl md:text-5xl lg:text-6xl",
				children: title
			}),
			sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-white/60",
				children: sub
			})
		]
	});
}
function PlayersCarousel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "jogadores",
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Escolha um craque",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Treine como um ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "craque"
				})] }),
				sub: "Cada jogador destrava um plano com foco em uma especialidade."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 flex snap-x snap-mandatory gap-5 overflow-x-auto pb-6 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
				children: players.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "group relative w-[280px] shrink-0 snap-start overflow-hidden rounded-3xl glass p-5 transition hover:-translate-y-1 md:w-[320px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mb-4 h-72 overflow-hidden rounded-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: p.img,
									alt: p.name,
									width: 768,
									height: 1024,
									loading: "lazy",
									className: "h-full w-full object-cover transition duration-700 group-hover:scale-105"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute left-3 top-3 rounded-full bg-[color:var(--neon)] px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-black",
									children: p.spec
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute bottom-3 left-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase tracking-widest text-white/60",
										children: "Craque"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xl",
										children: p.name
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2.5",
							children: Object.entries(p.stats).map(([k, v], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								label: k,
								value: v,
								delay: i * 120
							}, k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn-neon mt-5 w-full rounded-xl py-3 text-xs",
							children: "Treinar como ele"
						})
					]
				}, p.name))
			})]
		})
	});
}
function AppShowcase() {
	const screens = [
		"Home",
		"Treinos",
		"Perfil",
		"Evolução",
		"Ranking",
		"Desafios",
		"Conquistas",
		"Calendário",
		"Estatísticas",
		"IA Treinador"
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "app",
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Dentro do app",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Uma experiência ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "completa"
				})] }),
				sub: "Dark mode nativo. Design pensado para o esporte."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-[#0b0b0b] to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-[#0b0b0b] to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-6 overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex shrink-0 animate-marquee gap-6",
							children: [...screens, ...screens].map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniPhone, {
								label,
								index: i
							}, i))
						})
					})
				]
			})]
		})
	});
}
function MiniPhone({ label, index }) {
	const c = [
		"#b8ff00",
		"#00e0ff",
		"#ff00c8",
		"#ffd400"
	][index % 4];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative w-[200px] shrink-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-[2rem] bg-neutral-900 p-2 ring-1 ring-white/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex h-[380px] flex-col overflow-hidden rounded-[1.6rem] bg-black p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mb-3 h-2 w-16 rounded-full bg-white/10" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-widest text-white/40",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg",
						style: { color: c },
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-2",
						children: [...Array(4)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-white/5 p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mb-1 h-1.5 w-2/3 rounded bg-white/10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-1 w-1/2 rounded",
								style: {
									backgroundColor: c,
									opacity: .5
								}
							})]
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-auto rounded-xl p-3 text-center text-xs font-bold text-black",
						style: {
							backgroundColor: c,
							boxShadow: `0 0 20px ${c}80`
						},
						children: "Abrir"
					})
				]
			})
		})
	});
}
function EvolutionSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.3em] text-neon",
					children: "Evolução"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-3 font-display text-4xl md:text-5xl",
					children: ["Cada treino, um ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-neon",
						children: "novo nível"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-white/70",
					children: "XP, moedas, medalhas, conquistas — um sistema completo de recompensas que te faz querer treinar todos os dias."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid grid-cols-3 gap-4",
					children: [
						{
							l: "XP total",
							v: 28450,
							i: Zap
						},
						{
							l: "Conquistas",
							v: 47,
							i: Award
						},
						{
							l: "Moedas",
							v: 3820,
							i: Crown
						}
					].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl glass p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(x.i, { className: "h-5 w-5 text-[color:var(--neon)]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-2xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, { to: x.v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase text-white/50",
								children: x.l
							})
						]
					}, x.l))
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative rounded-3xl glass p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase text-white/50",
							children: "Sua evolução · 12 semanas"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl",
							children: "+218% de progresso"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-full bg-[color:var(--neon)]/10 px-3 py-1 text-xs text-neon",
							children: "↑ 12% esta semana"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 400 180",
						className: "h-52 w-full",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
								id: "g1",
								x1: "0",
								x2: "0",
								y1: "0",
								y2: "1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "0%",
									stopColor: "#b8ff00",
									stopOpacity: "0.6"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "100%",
									stopColor: "#b8ff00",
									stopOpacity: "0"
								})]
							}) }),
							[
								0,
								45,
								90,
								135
							].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "0",
								x2: "400",
								y1: y,
								y2: y,
								stroke: "rgba(255,255,255,0.05)"
							}, y)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: "M0,160 L40,150 L80,140 L120,120 L160,110 L200,90 L240,70 L280,55 L320,35 L360,25 L400,15 L400,180 L0,180 Z",
								fill: "url(#g1)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: "M0,160 L40,150 L80,140 L120,120 L160,110 L200,90 L240,70 L280,55 L320,35 L360,25 L400,15",
								stroke: "#b8ff00",
								strokeWidth: "2.5",
								fill: "none",
								style: { filter: "drop-shadow(0 0 6px #b8ff00)" }
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex justify-between text-[10px] uppercase text-white/40",
						children: [
							"S1",
							"S3",
							"S5",
							"S7",
							"S9",
							"S12"
						].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s }, s))
					})
				]
			})]
		})
	});
}
function Challenges() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Desafios do dia",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Missões ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "diárias"
				})] }),
				sub: "Complete objetivos e ganhe recompensas exclusivas."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-4",
				children: [
					{
						t: "100 Embaixadinhas",
						time: "5 min",
						xp: 120,
						r: "+1 estrela"
					},
					{
						t: "Sprint 30 metros",
						time: "8 min",
						xp: 180,
						r: "Selo Velocidade"
					},
					{
						t: "Controle de bola",
						time: "10 min",
						xp: 200,
						r: "Carta rara"
					},
					{
						t: "Finalização precisa",
						time: "12 min",
						xp: 250,
						r: "Moedas x50"
					}
				].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group relative overflow-hidden rounded-3xl glass p-6 transition hover:-translate-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-6 -top-6 h-24 w-24 rounded-full bg-[color:var(--neon)]/20 blur-2xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs uppercase tracking-widest text-neon",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "h-4 w-4" }), " Hoje"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 font-display text-2xl",
							children: c.t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-3 text-xs text-white/70",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1 rounded-full bg-white/5 px-3 py-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }), c.time]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1 rounded-full bg-white/5 px-3 py-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-3 w-3 text-[color:var(--neon)]" }),
										"+",
										c.xp,
										" XP"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1 rounded-full bg-white/5 px-3 py-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-3 w-3 text-[color:var(--neon)]" }), c.r]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn-neon mt-6 w-full rounded-xl py-2.5 text-xs",
							children: "Começar"
						})
					]
				}, c.t))
			})]
		})
	});
}
function PlayerCards() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Cartas colecionáveis",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Colecione seus ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "craques"
				})] }),
				sub: "Ganhe cartas holográficas ao completar treinos e desafios."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3",
				children: [
					{
						name: "R. Silva",
						rarity: "Lendário",
						lvl: 92,
						img: player_2_default,
						tint: "from-yellow-300 via-amber-400 to-orange-500"
					},
					{
						name: "J. Neto",
						rarity: "Épico",
						lvl: 88,
						img: player_1_default,
						tint: "from-fuchsia-400 via-purple-500 to-indigo-600"
					},
					{
						name: "M. Oliveira",
						rarity: "Raro",
						lvl: 84,
						img: player_4_default,
						tint: "from-sky-300 via-cyan-400 to-teal-500"
					}
				].map((c, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "group perspective",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto w-[280px]",
						style: { animation: `float-y ${5 + idx}s ${idx * .3}s ease-in-out infinite` },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -inset-2 rounded-3xl holo opacity-70 blur-md" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `relative overflow-hidden rounded-3xl bg-gradient-to-br ${c.tint} p-[2px]`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-3xl bg-neutral-950 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-3xl text-neon",
											children: c.lvl
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-white/10 px-2 py-0.5 uppercase tracking-widest",
											children: c.rarity
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative mt-2 h-64 overflow-hidden rounded-2xl",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: c.img,
											alt: c.name,
											className: "h-full w-full object-cover",
											loading: "lazy"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 holo mix-blend-overlay opacity-40" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-center font-display text-2xl",
										children: c.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 grid grid-cols-4 gap-1 text-center text-[10px] uppercase text-white/60",
										children: [
											"VEL",
											"DRI",
											"CHU",
											"PAS"
										].map((k, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-neon text-sm font-bold",
											children: 85 + (idx + i) % 10
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: k })] }, k))
									})
								]
							})
						})]
					})
				}, c.name))
			})]
		})
	});
}
function AiCoach() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex items-center gap-2 rounded-full bg-[color:var(--neon)]/10 px-3 py-1 text-xs uppercase tracking-widest text-neon",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "h-3.5 w-3.5" }), " IA Treinador"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-3 font-display text-4xl md:text-5xl",
					children: [
						"Seu coach ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-neon",
							children: "particular"
						}),
						", 24/7"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-white/70",
					children: "A IA analisa seus treinos, aponta pontos fracos e recomenda o próximo passo para você evoluir mais rápido — como se tivesse um treinador profissional no bolso."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 space-y-3 text-sm text-white/80",
					children: [
						"Análise em tempo real",
						"Feedback personalizado",
						"Reajuste automático do plano",
						"Alertas de recuperação"
					].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4 text-[color:var(--neon)]" }), t]
					}, t))
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative rounded-3xl glass p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center gap-3 border-b border-white/10 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex h-10 w-10 items-center justify-center rounded-2xl bg-[color:var(--neon)] text-black",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "h-5 w-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -right-0.5 -bottom-0.5 h-3 w-3 rounded-full border-2 border-black bg-green-400" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg",
						children: "Copa AI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-white/50",
						children: "Online agora"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: [
						{
							me: false,
							t: "Bom dia, Lucas 👋 Notei que você treinou menos que ontem."
						},
						{
							me: false,
							t: "Que tal completar mais 1 treino de explosão hoje?"
						},
						{
							me: true,
							t: "Bora! Manda aí."
						},
						{
							me: false,
							t: "Seu chute melhorou 12% nas últimas 2 semanas ⚡"
						},
						{
							me: false,
							t: "Velocidade +6%. Novo nível desbloqueado: OURO 🏆"
						}
					].map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `flex ${m.me ? "justify-end" : "justify-start"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${m.me ? "bg-[color:var(--neon)] text-black" : "bg-white/5 text-white/90"}`,
							children: m.t
						})
					}, i))
				})]
			})]
		})
	});
}
function StatsProgress() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Estatísticas",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"Tudo o que ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-neon",
						children: "você"
					}),
					" conquista"
				] }),
				sub: "Acompanhe cada atributo evoluir em tempo real."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-14 grid grid-cols-1 gap-8 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-3xl glass p-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-5",
						children: [
							{
								l: "Velocidade",
								v: 92
							},
							{
								l: "Resistência",
								v: 87
							},
							{
								l: "Força",
								v: 81
							},
							{
								l: "Passe",
								v: 84
							},
							{
								l: "Finalização",
								v: 89
							},
							{
								l: "Explosão",
								v: 90
							},
							{
								l: "Controle",
								v: 86
							}
						].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
							label: s.l,
							value: s.v,
							delay: i * 100
						}, s.l))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-5",
					children: [
						{
							i: Trophy,
							l: "Vitórias",
							v: 148
						},
						{
							i: Target,
							l: "Precisão",
							v: 92,
							suf: "%"
						},
						{
							i: Flame,
							l: "Streak",
							v: 42,
							suf: " dias"
						},
						{
							i: Award,
							l: "Medalhas",
							v: 27
						}
					].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl glass p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(k.i, { className: "h-6 w-6 text-[color:var(--neon)]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-display text-4xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, {
									to: k.v,
									suffix: k.suf || ""
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs uppercase text-white/50",
								children: k.l
							})
						]
					}, k.l))
				})]
			})]
		})
	});
}
function Ranking() {
	const list = [
		{
			r: 1,
			name: "Lucas F.",
			city: "SP",
			lvl: 45,
			medal: "🥇"
		},
		{
			r: 2,
			name: "Pedro R.",
			city: "RJ",
			lvl: 42,
			medal: "🥈"
		},
		{
			r: 3,
			name: "João C.",
			city: "MG",
			lvl: 40,
			medal: "🥉"
		},
		{
			r: 4,
			name: "Diego M.",
			city: "BA",
			lvl: 38,
			medal: ""
		},
		{
			r: 5,
			name: "André T.",
			city: "PR",
			lvl: 37,
			medal: ""
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Ranking mundial",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"Onde você ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-neon",
						children: "chegará"
					}),
					"?"
				] }),
				sub: "Compete com atletas do mundo todo, semana após semana."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 overflow-hidden rounded-3xl glass",
				children: list.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex items-center gap-4 px-6 py-4 transition hover:bg-white/[0.04] ${i < list.length - 1 ? "border-b border-white/5" : ""} ${p.r <= 3 ? "bg-[color:var(--neon)]/5" : ""}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "w-8 font-display text-2xl text-neon",
							children: ["#", p.r]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-2xl",
							children: p.medal || "🎖️"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-lg",
								children: p.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-white/50",
								children: p.city
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-xl text-neon",
								children: ["Nv ", p.lvl]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase text-white/40",
								children: "Nível"
							})]
						})
					]
				}, p.r))
			})]
		})
	});
}
function Testimonials() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Depoimentos",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Atletas que ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "evoluíram"
				})] }),
				sub: "Resultados reais de quem já treina no Treino da Copa."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid grid-cols-1 gap-6 md:grid-cols-3",
				children: testimonials.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "rounded-3xl glass p-6 transition hover:-translate-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-4 flex gap-0.5",
							children: [...Array(5)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4 fill-[color:var(--neon)] text-[color:var(--neon)]" }, i))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
							className: "text-white/85",
							children: [
								"\"",
								t.text,
								"\""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
							className: "mt-6 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: t.img,
								alt: t.name,
								width: 48,
								height: 48,
								loading: "lazy",
								className: "h-12 w-12 rounded-full object-cover ring-2 ring-[color:var(--neon)]/30"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-lg leading-tight",
								children: t.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-white/50",
								children: t.city
							})] })]
						})
					]
				}, t.name))
			})]
		})
	});
}
function Comparison() {
	const rows = [
		[
			"Plano personalizado",
			false,
			true
		],
		[
			"Gamificação e XP",
			false,
			true
		],
		[
			"IA Treinador",
			false,
			true
		],
		[
			"Desafios diários",
			false,
			true
		],
		[
			"Ranking mundial",
			false,
			true
		],
		[
			"Progresso mensurável",
			false,
			true
		],
		[
			"Cartas colecionáveis",
			false,
			true
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "A diferença",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Antes e depois do ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "app"
				})] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid grid-cols-1 gap-5 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-white/10 bg-white/[0.02] p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-white/60",
						children: "Sem o app"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 space-y-3",
						children: rows.map(([label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 text-white/60",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4 text-red-400" }), label]
						}, label))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl bg-gradient-to-br from-[color:var(--neon)]/15 to-transparent p-6 ring-1 ring-[color:var(--neon)]/40 glow-neon-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-neon",
						children: "Com Treino da Copa"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 space-y-3",
						children: rows.map(([label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-[color:var(--neon)]" }), label]
						}, label))
					})]
				})]
			})]
		})
	});
}
function Benefits() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Benefícios",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Tudo dentro de um ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "único app"
				})] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5",
				children: [
					{
						i: Dumbbell,
						t: "Treinos exclusivos"
					},
					{
						i: Brain,
						t: "IA personalizada"
					},
					{
						i: Sparkles,
						t: "Gamificação"
					},
					{
						i: Trophy,
						t: "Ranking mundial"
					},
					{
						i: Award,
						t: "Conquistas"
					},
					{
						i: Flame,
						t: "Desafios diários"
					},
					{
						i: Calendar,
						t: "Calendário"
					},
					{
						i: Bell,
						t: "Lembretes inteligentes"
					},
					{
						i: WifiOff,
						t: "Modo offline"
					},
					{
						i: RefreshCw,
						t: "Atualizações semanais"
					}
				].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group rounded-2xl glass p-5 text-center transition hover:-translate-y-1 hover:bg-white/[0.06]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(b.i, { className: "mx-auto h-8 w-8 text-[color:var(--neon)] transition group-hover:scale-110" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm font-semibold",
						children: b.t
					})]
				}, b.t))
			})]
		})
	});
}
function Pricing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "planos",
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Planos",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Escolha o seu ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "plano"
				})] }),
				sub: "Comece grátis. Faça o upgrade quando quiser evoluir mais rápido."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-14 grid grid-cols-1 gap-6 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl glass p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-white/50",
							children: "Aplicativo Copa 2026"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-5xl",
							children: "R$ 5,99"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-white/50",
							children: "por mês"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 space-y-3 text-sm text-white/80",
							children: [
								"5 treinos por semana",
								"3 jogadores para treinar",
								"XP, nível e conquistas",
								"Acesso à comunidade"
							].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-white/50" }), t]
							}, t))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://pay.cakto.com.br/fc9rfzf_959502",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "mt-8 block text-center w-full rounded-xl border border-white/15 py-3 text-sm font-semibold hover:bg-white/5 transition",
							children: "Assinar Agora"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-3xl p-[2px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 holo opacity-90" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative rounded-[calc(1.5rem-2px)] bg-neutral-950 p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 inline-flex items-center gap-1 rounded-full bg-[color:var(--neon)] px-2.5 py-0.5 text-[10px] font-bold uppercase text-black",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-3 w-3" }), " Mais popular"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-widest text-neon",
								children: "Premium"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-baseline gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-6xl text-neon",
									children: "R$ 21,90"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-white/60",
									children: "/mês"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-white/50",
								children: "ou R$ 147/ano · economize 44%"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-8 space-y-3 text-sm",
								children: [
									"Treinos ilimitados",
									"Todos os craques desbloqueados",
									"IA Treinador personalizado",
									"Ranking mundial e desafios",
									"Cartas colecionáveis holográficas",
									"Modo offline e sem anúncios",
									"Atualizações semanais vitalícias"
								].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-[color:var(--neon)]" }), t]
								}, t))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://pay.cakto.com.br/rk4igdg_959513",
								target: "_blank",
								rel: "noopener noreferrer",
								className: "btn-neon mt-8 block text-center w-full rounded-xl py-3.5",
								children: "Quero ser Premium"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-center text-[11px] text-white/50",
								children: "Garantia de 7 dias · Cancele quando quiser"
							})
						]
					})]
				})]
			})]
		})
	});
}
function FAQ() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "faq",
		className: "py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				over: "Dúvidas",
				title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Perguntas ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "frequentes"
				})] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 space-y-3",
				children: faq.map((f, i) => {
					const isOpen = open === i;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-2xl glass",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setOpen(isOpen ? null : i),
							className: "flex w-full items-center justify-between gap-4 px-5 py-4 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: f.q
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-5 w-5 text-[color:var(--neon)] transition-transform ${isOpen ? "rotate-180" : ""}` })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `grid transition-all duration-300 ${isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden px-5 pb-4 text-sm text-white/70",
								children: f.a
							})
						})]
					}, f.q);
				})
			})]
		})
	});
}
function FinalCTA() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden py-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: stadium_cta_default,
				alt: "",
				width: 1920,
				height: 1080,
				loading: "lazy",
				className: "absolute inset-0 -z-10 h-full w-full object-cover opacity-70"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -z-10 bg-gradient-to-b from-black/40 via-black/70 to-[#0b0b0b]" }),
			[...Array(24)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute h-1.5 w-1.5 rounded-full bg-[color:var(--neon)] shadow-[0_0_10px_var(--neon)]",
				style: {
					top: `${i * 41 % 100}%`,
					left: `${i * 23 % 100}%`,
					animation: `float-y ${3 + i % 5}s ${i * .1}s ease-in-out infinite`,
					opacity: .6
				}
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.4em] text-neon",
						children: "Última chance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-4 font-display text-5xl leading-[0.95] sm:text-7xl md:text-8xl",
						children: [
							"SEU PRÓXIMO NÍVEL",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-neon",
								children: "COMEÇA HOJE"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-6 max-w-xl text-white/70",
						children: "Entre para o time de mais de 120.000 atletas que já estão treinando como craques da Copa."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "#planos",
						className: "btn-neon mt-10 inline-flex items-center gap-2 rounded-2xl px-8 py-5 text-base md:text-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "h-5 w-5" }), " Quero treinar como um craque"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 flex flex-wrap justify-center gap-4 text-xs text-white/60",
						children: [
							{
								i: Shield,
								l: "Pagamento seguro"
							},
							{
								i: Check,
								l: "Garantia de 7 dias"
							},
							{
								i: Sparkles,
								l: "Suporte 24/7"
							},
							{
								i: RefreshCw,
								l: "Atualizações vitalícias"
							}
						].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 rounded-full glass px-3 py-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(x.i, { className: "h-3.5 w-3.5 text-[color:var(--neon)]" }), x.l]
						}, x.l))
					})
				]
			})
		]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-white/5 bg-black py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl grid-cols-2 gap-8 px-6 md:grid-cols-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-sm text-sm text-white/60",
						children: "Treine como os jogadores da Copa. Um app criado para levar você ao próximo nível."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 flex gap-3",
						children: [
							Instagram,
							Youtube,
							Twitter
						].map((I, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#",
							"aria-label": "Social",
							className: "flex h-9 w-9 items-center justify-center rounded-xl glass transition hover:bg-[color:var(--neon)] hover:text-black",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I, { className: "h-4 w-4" })
						}, i))
					})
				]
			}), [{
				t: "Produto",
				l: [
					"App",
					"Recursos",
					"Planos",
					"Novidades"
				]
			}, {
				t: "Suporte",
				l: [
					"Contato",
					"Ajuda",
					"Política",
					"Termos"
				]
			}].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-xs uppercase tracking-widest text-neon",
				children: c.t
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2 text-sm text-white/70",
				children: c.l.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#",
					className: "hover:text-white transition",
					children: x
				}) }, x))
			})] }, c.t))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-10 flex max-w-7xl flex-col items-center justify-between gap-3 border-t border-white/5 px-6 pt-6 text-xs text-white/40 md:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "© 2026 Treino da Copa. Todos os direitos reservados." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Feito com ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-neon",
					children: "■"
				}),
				" para atletas."
			] })]
		})]
	});
}
//#endregion
export { Index as component };
